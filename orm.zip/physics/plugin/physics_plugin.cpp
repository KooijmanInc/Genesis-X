// SPDX-License-Identifier: (LicenseRef-KooijmanInc-Commercial OR GPL-3.0-only)
// Copyright (c) 2025 Kooijman Incorporate Holding B.V.

#include <QtPlugin>
#include <QObject>

class PhysicsModule : public QObject
{
    Q_OBJECT
public:

};

// #include "physics_plugin.moc"

