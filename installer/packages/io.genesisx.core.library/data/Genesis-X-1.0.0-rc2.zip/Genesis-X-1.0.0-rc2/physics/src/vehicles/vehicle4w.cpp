// SPDX-License-Identifier: (LicenseRef-KooijmanInc-Commercial OR GPL-3.0-only)
// Copyright (c) 2025 Kooijman Incorporate Holding B.V.

#include "GenesisX/vehicles/vehicle4w.h"

using namespace gx::physics;

// Vehicle4W::Vehicle4W(QObject* parent)
//     : QObject{parent}
// {

// }

Vehicle4W::Vehicle4W(QObject *parent)
    : QObject{parent}
{

}
